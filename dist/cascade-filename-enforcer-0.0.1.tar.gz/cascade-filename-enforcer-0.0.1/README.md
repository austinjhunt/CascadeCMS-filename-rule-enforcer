# Cascade CMS Filename Rule Enforcer
This package was developed to automate the enforcement of file naming conventions in an enterprise instance of Cascade CMS 8 for the College of Charleston, but has been re-written in a way that allows you to set the configuration for your own Cascade CMS environment. With over 100 sites to manage, and each site containing improperly named resources that were allowed in the previous Cascade Server 7 from which we migrated, we needed a way of automatically detecting improper file names (file names with spaces and capitalized letters) and fixing them dynamically. This package handles that automation in an object-oriented way. 

## How To Use 

## Assumptions 
/content